# Profile test proposal v3

Unexecuted integration proposal: `profile-test-v3.sh`, SHA-256 `bd2bdedbbfeebaf64eb9369dd6b077ad0176a42e64a914a17b97b2d0f0b837a9`. Diff from the tracked tool: **468 added / 2 removed lines**. Earlier proposals remain unchanged.

This version retains the v1 coverage in `profile-test-proposal.md` and adds the requested deterministic publication cases, the same-source ordinary/profiled hot-loop comparison, and the admitted additive role fixture (`184adbc8dd758c72474f268122602285468e99d2b21362216b9c5918b6e79fd4`).

## Added controls

- `copy_samples` is built ordinarily at inline64 and executed once; its stdout must equal the profiled image's stdout. This checks the actual hot sampled copy loop.
- `copy_roles` runs through the original-IR interpreter and ordinary native paths, both yielding `297\n`. A short inline0 profiled image must execute its source assertions successfully, then produce a valid checked-companion detail report. A standalone scalar build has no result FD and deliberately emits no scalar stdout, so the script does not compare that empty stdout to the run command's formatted value.
- Metadata asserts incoming/return widths 1, 16 and 256; original constructor subsites 1 and 3; local, array, repeat, vector, box and view roles; projected-read flags 1/2/3/4 and projected-write flags 1/2. It does not require samples at any particular role.
- Root's retained 58-row report (`roles-profile-detail-1/stdout`, SHA-256 `7fc74a8882e9ddbf42c582a5e00ff89c668901a77153e0eea053ffa708ac219b`) and selected IR were read without another compiler run. Compound-reference/indexed assignments in that IR use Replace, so destination flags 3/4 are not asserted. Instead the helper requires Replace instructions and rejects any copy-site row assigned to them.
- Same output path and the same retained parent/name through a `/./` spelling must reject with E_PROFILE_OUTPUT, retaining old bytes.
- A nonwritable owned companion parent must fail its temporary creation with exact EACCES, remove the staged image, and retain both old outputs. Only for uid 0, the child uses the existing util-linux `setpriv` to drop DAC_OVERRIDE and DAC_READ_SEARCH; the exact compiler diagnostic prevents an unavailable tool or earlier access failure from satisfying the case. The trap restores permission on that one owned parent.
- A nonempty directory at the final image name forces the second rename to fail with EISDIR. The old directory and marker survive; the companion already published by the first rename must equal the exact selected companion. No successful-pair claim is made.
- Every publication refusal requires no remaining stage name and no newly remembered `image-*` or `inputs-image-*` record in the isolated store.

The private key stays in an owned external `/tmp/compiler-profile-key.XXXXXX` directory. No unrelated source, service, credential or store is modified. No observer, race, kill, source wrapper, profiling benchmark or timing claim is added.

Static shell and embedded-Perl syntax checks passed in `compiler-copy-tests-static3-1178`. No compiler, native/interpreter entry, profile report or generated fixture was executed by this agent. Root owns the combined integration run and any resulting evidence.
