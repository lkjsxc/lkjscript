# Profile test proposal

This is an unexecuted proposal for `tools/profile-test.sh`. The tracked tool and all source fixtures remain unchanged.

- Baseline tool SHA-256: `e3245e18c870a6961c06fcaa3d1d2a0d6063cd370444e446614187a5d480e262`.
- Proposed tool SHA-256: `8bd562bb8e500f168960cb5add107fdab0f490fd9b1c1603b377da1152487388`.
- Proposed delta: 307 added / 2 removed lines.
- Given root fixture SHA-256: `6c0044da5ae313a54c4d392c7f6cc540732ff30d746dfaaf5d5fb444ced0d466`.
- Profiler proposal v2 SHA-256: `f84525e59ec9936b2f4df617601e5f9e1b94ba27df941d657c4c46160d9ff42f`. Root's import-qualified v3 is reported as `a57da9cbc0627bdc83e416e4c2675c10e46270082e2cdfa4d3f65344c80af44e`; the proposed API and format remain unchanged.

Static preparation checked shell syntax and the embedded Perl's syntax only (gateway request `compiler-copy-tests-static-1162`). No compiler, profile, generated fixture, observer, signal or race test ran. The earlier preparation isolate failed before a tool call because an embedded Perl dereference was parsed as JavaScript interpolation; no file was written by that attempt.

## Coverage

The old arithmetic entry and its ordinary-report assertions remain in place. The added commands select `copy_once` for short interpreter/native value parity and `copy_samples` for the copy-bearing native profile. The script does not require every site to receive samples, and pagination retains zero-count rows.

Ordinary `ir` output with inline64 must equal the original no-opt IR. The companion must preserve the function slots while eliminating the known small `profile_value` calls, and cold stats must show accepted inlining. This proves selection changed and that the companion reports that selection; it does not infer that scalar inlining moved a copied instruction. The raw profile's digest must equal the exact companion SHA-256.

A fresh isolated store is built twice at the same output path. Between builds only the companion is removed. The warm build must regenerate it, use native fragments, bypass whole-image return, and reproduce both native image and companion bytes. The private 32-byte key is created under an owned `/tmp/compiler-profile-key.XXXXXX` directory outside the default repository source grant, library and runtime grants.

The copy report is exercised once with a complete output bound and then in a bounded traversal beginning with one row. Concatenated rows must match. Checks include exact byte-cap acceptance, one-byte-short refusal, tiny header and terminal zero-row caps, canonical cursor ordinals, profile/companion pins, explicit required bounds, and positive zero-row terminal output.

Eleven owned-file mutations cover range, owner, type, width, instruction, subsite, synthetic parameter sentinel, reserved tags, function map, trailing byte and truncation. A byte-changed companion must fail digest binding; a companion with a correct new digest but an invalid local type must reach independent IR checking and refuse there.

Synthetic counters cover completed accounting, serial-leading accounting, one leading site or unmapped sample, every specified inconsistent gap and sum overflow. They are static artifact edits, not an observer or termination campaign. Original serial-gap/default-report compatibility remains covered.

## Integration responsibilities

Root owns application of source proposals and execution of this tool. Scale's additive `copy_roles` fixture can add a short native/interpreter parity pair at the existing copy-entry section; it is not duplicated here. Fragment malformed-metadata/preflight unit checks remain in the native/cache proposal. Driver image/companion destination identity and partial-publication tests remain separate from this report-focused script.

The test adds no timing percentage requirement and produces no new optimization claim. Its expected positive real observation is only at least one mapped KIND_COPY sample from the dedicated copy workload.
