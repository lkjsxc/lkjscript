# Copy-site profiler candidate: focused integration proposal

Status: prospective tests for the untrusted candidate only. No compiler, profile, benchmark, observer, kill campaign or fixture execution has occurred in this preparation.

## Frozen proposal

- Baseline tracked `src/native/profiling.lkj`: `a732a5f73defdf5236a2e631552c14367a8f4a105c987ed2c44a0f8d0ed00d6e`.
- Candidate `profiling.lkj`: `0b19643d64462525be325dfba5f0a4018b3d79740a4373288f71b2f20a7de57a`.
- Plan: `bench/compiler-profile-copy-sites-plan.md`, SHA-256 `b9de2760c582d33eedea3060a59f0502263335ca0667e597c34d4082bc8d9a52`.
- The sole candidate production file is under the owned `target/compiler-copy-sites-profiler-candidate` directory. Root must apply it through checked structural operations; its presence is not admission.
- Dependencies: the agreed `x86::CopySite`, constants and `valid_copy_tags`; `native::copy_contract`; unchanged `ir_text::write/read`, independent `check::check_all`, and native `Layouts`.

## Exact interface and format

`data` appends `program: &ir::Program, functions: &[Label], copies: &[CopySite]` to its existing arguments and returns `Result<(), Diagnostic>`. It independently preflights selected-IR copy contracts, widths, native function/kind containment, offsets, framing and publication extent before binding any data label. The selected-IR digest is computed inside this opt-in function. Non-profiled emission never calls it.

`copy_report(bytes: &[u8], companion: &[u8], limit: usize, max_bytes: usize, cursor: Option<&str>) -> Result<String, String>` parses the entire sample artifact, binds exact companion bytes, independently checks that IR, and only then derives operand roles/layout. It does not turn a profile file into an admission proof or a runtime attestation. Input checking and sorting are whole-artifact work; the bounded output is not a semantic-query latency promise.

LKJPROF4 uses the agreed 160-byte header, 64-byte existing symbol rows, 16-byte kind intervals, 16 existing counters, 72-byte copy rows, and 16-byte function-map rows. Header words 72 and 152 are zero; period remains exactly 1,000,000 ns. Names, kinds, counters, copies and map are contiguous, and map end equals EOF. Copy rows use absolute emitted addresses; selected-IR indices remain scoped to the exact companion. The public continuation `4:PROFILE_SHA256:COMPANION_SHA256:NEXT` is an exact-content selector, not an HMAC or authenticated store cursor.

Default `report` retains its previous layout and at most 37 lines, with additional structural validation. Detail output consists of two header lines, complete copy rows, and one continuation line; every byte counts toward `--bytes`. No partial output is returned on error. Rows sort by descending samples, then function/instruction/subsite/start/end. Changing `--limit` or `--bytes` does not change the pinned ordering.

## Narrow regression cases

Retain the existing `tools/profile-test.sh` native-value, recursive inclusion, escaped-name, denied sampling path, malformed category metadata, serial gap and default line-bound assertions. The new parser should make its existing malformed cases fail for the same relevant reason; do not replace them with a stale magic-only rejection.

1. **Canonical v4 framing.** From one emitted profile with its exact companion, accept default and detail routes. A zero-copy profile is valid and ends with a bounded zero-row continuation. Reject truncated header/row/name/kind/counter/copy/map, extra tail, changed magic/reserved words/period, noncontiguous offsets, overflow-sized counts and names, invalid UTF-8, invalid function-map row index, duplicate symbol owner, nonexistent symbol, impossible frame range, copy overlap or zero-width interval, body/parameter sentinel mismatch, reserved tags, and a site crossing its symbol or KIND_COPY interval. Keep a valid adjacent-interval control.
2. **Independent IR boundary.** Changed companion bytes reject by digest. A fixture that updates the header digest to malformed IR still rejects parsing; a well-formed but ill-typed IR with its correct digest rejects independent checking before any layout access. Wrong body index, parameter index, original constructor subsite, type index, role, place flags or width rejects against the checked companion. Name/file/first-line map mismatch also rejects. No arbitrary source file is read from companion locations.
3. **Synthetic handler accounting.** Construct or patch owned fixture counts without executing a signal observer. With S=serial, T=sum of all kinds, K=KIND_COPY and D=sum of copy-site counters plus unmapped: accept S=T,D=K; accept S=T+1,D=K; accept S=T+1,D=K+1 and report in-flight=1. Reject S<T, S>T+1, D<K, D>K+1, and D=K+1 when S=T. Exercise both one leading mapped counter and one leading unmapped counter; do not choose or decrement an arbitrary row. Reject u64 sum overflow. The existing serial+1 default-report equality control remains valid.
4. **Bounded detail and stable continuation.** Limit=1 must produce a real continuation when C>1; traverse once and compare the concatenated row sequence with one sufficiently bounded complete response. Include equal sample counts, multiple sites at one instruction with original element indices, synthetic incoming parameters and UTF-8/control-bearing names. Reject zero limit/bytes, too-small header budget, oversized first complete row, malformed/noncanonical ordinal, changed profile digest, changed companion digest and an ordinal beyond C. Resume at C with a tiny byte cap must reject, not emit an oversized zero-row header/footer. Final replies must never exceed the exact byte cap, including the cursor.
5. **Real collection coverage.** With the jointly integrated emitter, cover all supported role pairs and original constructor indices with scalar gaps. Zero-size and coalesced transfers emit no site. Widths 1/2/4/8, 16/24/32, 33..128 and 129+, overlap and nonoverlap preserve original-IR interpreter values. Runtime/allocator overrides, variable p.copy, Replace swaps and scalar/frame/address work remain excluded, rather than assigned a guessed copy owner. One CPU-bearing copy fixture should yield nonzero observed copy-site samples, without a fixed percentage assertion.
6. **Cross-owner integration.** Scale's cold/warm fragment tests must compare exact rows and offsets, and refuse malformed metadata before assembler mutation. Root's companion route must use the same selected checked native IR (including rejected-transform fallback), bypass an image-only early return unless a companion is already proven, and reject image/IR destination aliasing by held parent identity plus basename. The driver's immutable owned inputs must be passed to the report; a partial publication or wrong companion cannot be accepted as matching.

## Handler review points

The added binary search runs only when the existing classifier selected KIND_COPY. It preserves B, R12, R13, R14 and R15 (unwind state and interrupted RIP), uses no allocator or application-side transfer counter, and commits the site or unmapped detail counter before the existing kind counter. Existing Linux SIGPROF blocking and rt_sigreturn behavior are unchanged. The reported single in-flight ambiguity covers the detail-before-kind interruption; it does not justify any larger mismatch.

## Deliberate limits

This candidate has not been compiled or executed. No new attribution or speed claim exists. The old 10.369% copy marginal remains historical; sample count multiplied by width is not bytes copied or removable time. The exact selected IR can support a later escape/ownership census, but this implementation does not infer Copy, freshness, nonescape, scalar replacement opportunity or an inline call chain from a native copy interval. New construction memory, profile growth, runtime overhead and selected-IR size require the separately frozen measurement cohort.
