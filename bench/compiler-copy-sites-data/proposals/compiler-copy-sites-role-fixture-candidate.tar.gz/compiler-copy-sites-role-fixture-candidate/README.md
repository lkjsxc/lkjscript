# Additive copy-role fixture proposal

Prepared statically; no compiler, interpreter, native image, profile, or test was run.
Root owns semantic application and validation.

## Preserved source and additions

The proposal preserves every byte of the 1,109-byte driver fixture:
`/home/coder/workspace/lkjscript/target/compiler-copy-sites-driver-candidate/profile.lkj`,
SHA-256 `6c0044da5ae313a54c4d392c7f6cc540732ff30d746dfaaf5d5fb444ced0d466`.
A newline and nine new top-level items follow that complete prefix.
Thus existing main, copy_once, copy_samples and their dependencies stay byte-identical.
`additions.json` contains nine unapplied add-item operations against `crate`;
`additions.lkj` is the same ordered source, and `profile.lkj` is the complete proposed projection.
The root fixture transaction may combine these additions with its existing additions.

The new entry is `copy_roles() -> u64`, with expected result **297** and value assertions.
It performs two vector pushes, one pop, one box allocation, and short fixed array initialization;
it adds no sampling-duration loop. All function/aggregate names are listed in `identities.txt`.

## Exact source/emitter coverage

Run this entry with output inlining disabled so the declared ABI boundaries remain.
These are source-derived expectations to check against the exported selected IR and recorded rows,
not observations from an executed candidate.

| Work | Source items / statements | Expected retained copy metadata |
|---|---|---|
| Small and large incoming / returned payloads | copy_role_byte, copy_role_pair, copy_role_wide | Incoming parameter sentinel with subsite 0; Local to ABIResult; widths 1, 16, 256 bytes |
| Fat incoming / returned view | copy_role_text | Incoming parameter and ABIResult, 16 bytes |
| Whole-local copy with a live source | local_copy = pair, with pair still used later | Local to Local, 16 bytes; the storage coalescer cannot merge the live source |
| Field reads and writes | frame.small and frame.wide | TypedPlace to Local / Local to TypedPlace, Field flag, 16 and 256 bytes |
| Compound projected access | reference.small through a retained mutable reference | Same roles with Deref + Field flags, 16 bytes |
| Indexed aggregate reads and writes | repeated[1], array[0], array[1] | TypedPlace index projection, 16 bytes |
| Constructor scalar gaps | CopyRoleFrame and CopyRoleChoice::Value | Aggregate payloads at original subsites **1** and **3**, widths 16 and 256; scalar fields at 0 and 2 have no copy row |
| Explicit aggregate array | array = [first, replaced] | Local to ArrayElement, original subsites 0 and 1, 16 bytes |
| Repeated aggregate array | repeated = [pair; 3] | Local to RepeatedArrayElement, one static subsite 0, 16 bytes |
| Vector transfer | values.push and values.pop | Local to VecElement; VecElement to ResultVariantField, 16 bytes |
| Box payload and dereference | Box::new(pair), original_box = *boxed, *boxed = indexed | Local to BoxPayload; TypedPlace Deref reads/writes, 16 bytes |
| Derived aggregate clone | pair.clone() | Actual current lowering is a generated function with an Op::Read through Deref, followed by aggregate return; it is **not** IntrinsicOp::Clone |
| String/byte view conversion | text.as_bytes(), while text remains used | ViewHeader to ViewHeader, 16 bytes, carrying the source view type |

The 1-byte struct is deliberately an aggregate: native Layouts marks Struct storage nonscalar.
The existing CopyWide is 32 u64 words, so its payload is 256 bytes.
Native copies of scalar array elements in [17u64;32] and [31u64;32] are not separate copy-site rows.

No row needs positive samples in this short fixture. Profile startup writes the immutable map
before sampling starts; zero-count rows remain useful metadata evidence. The existing copy_samples
entry retains the independent long-running sampling control.

## Focused selection plan

Use the same integrated candidate, explicit fixture path and ordinary resource/load wrapper as the
other focused tests. Run each command only when root releases validation.

1. Run the unmodified original-IR interpreter path for `copy_roles` with `--inline-limit 0 --no-store`.
2. Run the ordinary native path for the same entry/options. Require both successful outputs to equal
   `297\n`; all source assertions must also pass.
3. Build that same entry with `--inline-limit 0 --no-store --profile --profile-ir COMPANION -o IMAGE`.
   Execute it once and compare its output with both oracles.
4. Read its copy-site report using the exact companion, positive bounds (for example
   `--limit 64 --bytes 32768`) and all returned continuations. Require valid companion checking,
   bounded complete rows, and the actual role/width/subsite combinations above. Do not require
   per-site samples or assume a fixed overall site count: ordinary source-library implementations
   can add correctly mapped rows.
5. Keep the existing copy_once inlining, cold/warm fragment, and copy_samples accounting tests
   separate. This entry is for operation roles and value parity; it is not a speed measurement.

## Explicit raw-Clone boundary

Source Clone coverage does not establish the dedicated Referent role. In
`src/elaborate/derive_methods.lkj::Generated::clone_value`, a derived Copy nominal is lowered to an
ordinary read of its referent. The source fixture therefore tests the resulting TypedPlace/Deref
contract instead of asserting a nonexistent raw intrinsic.

An existing checked-IR specimen,
`tests/semantics/ir/direct_ir_clone_cannot_erase_aggregate_provenance_0001.lkjir`,
has `expect: check` and a raw Clone of an 8-byte Copy View; its _0000 companion is an E_BORROW refusal.
It provides existing checker coverage, but its only function is transfer(&i64) -> View with no
runnable zero-argument entry. The values/reference/conformance IR search found no runnable raw
Clone specimen. This proposal leaves dedicated Referent runtime-row coverage explicitly open;
it does not add a source intrinsic or manufacture a new raw program.

## Admitted-form references

The source forms follow existing conformance specimens:
backend_copy_probe (retained Copy alias and projection),
array_repeat_compact (aggregate arrays/repeats, indexed mutations and enum payloads),
struct_copy (Copy pairs),
vec_affine (push/pop and matching Some/None),
scalar_clone_custom_copy and scalar_clone_views (declared/derived Clone and view behavior),
box_move (owned Box value), and generic_view_arguments (mutable view projection).
Field access through Box or Ref is explicitly implemented in elaborate's field-place lowering.
No owned-array iteration, constant-pattern tuple, or usize.to_string form is introduced.
