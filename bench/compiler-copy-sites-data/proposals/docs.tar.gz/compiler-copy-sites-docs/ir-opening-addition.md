`ir` serializes the admitted original program. Native emission may instead use
a rechecked optimization of that program. `build --profile --profile-ir PATH`
writes the exact checked IR selected for native emission, including the
original fallback when an optimization candidate is rejected. See
[native CPU profiles and selected IR](#native-cpu-profiles-and-selected-ir).

