Reports survive exit/signals; default summaries show self/inclusive functions and exclusive kinds
