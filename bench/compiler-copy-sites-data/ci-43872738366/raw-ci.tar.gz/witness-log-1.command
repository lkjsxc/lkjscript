gh api repos/lkjsxc/lkjscript/actions/jobs/133317833494/logs
