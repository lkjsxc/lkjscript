gh api repos/lkjsxc/lkjscript/actions/runs/43872738366/jobs?filter=latest&per_page=100
