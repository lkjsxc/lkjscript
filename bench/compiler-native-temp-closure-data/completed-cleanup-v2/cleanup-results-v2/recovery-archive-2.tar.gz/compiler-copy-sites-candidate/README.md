# Untrusted native copy-site candidates

These four files are proposals only. They were prepared beneath this ignored
target directory from main `9cc962a3`, whose `src/` and `library/` trees match
the accepted `62fa76f4` producer source. No tracked production source changed,
no manual source commit was created, and no compiler, profile or benchmark
command ran. Root will combine them with the separate driver/profiler proposals
and apply the complete change through a checked structural transaction.

The accepted contract is
`bench/compiler-profile-copy-sites-plan.md`, SHA-256
`b9de2760c582d33eedea3060a59f0502263335ca0667e597c34d4082bc8d9a52`.

## Files and shared interface

| Candidate | SHA-256 |
| --- | --- |
| src/x86.lkj | 6e25b0a456cc2bd278f30ebca7eeb7d8a3932e1235401502a9c27c39ecc54e09 |
| src/native/cache.lkj | 2b125a813e20f04fb2d5a939a4e5f81f252082e0ca882ba840341be2244c1da1 |
| src/native.lkj | 8443ca135131e565c01d311533c4fc976dea74c7177f14d19fbb8f8dc86a54f4 |
| src/native/intrinsics.lkj | 22b0cb4fd6e6bbe469d514a7ba25cfdb4be64784a5df683aaa11cd3f014d97c8 |

`x86::CopySite` is the agreed eight-word construction record:
public usize start/end/function/instruction/subsite/ty, and public u64 width/tags.
The module exposes the fixed COPY_ORIGIN_* / COPY_ROLE_* constants,
`valid_copy_tags`, and the internal `copy_interval` structural validator.
Assembler supplies `copy_sites_enabled`, `record_copy_site` and
`take_copy_sites`.

`native::copy_contract(program, function, instruction, subsite)` returns
Option<(payload type, tags)> for the exact selected IR. It is shared by
collection, native-fragment preflight and the separate profile detail reader.
Projected types use the existing bounds-safe `check::place_type`.
Place flags classify Field/VariantField as local aggregate projection (1),
Deref (2), and Index (4), retaining combinations. The StrAsBytes payload type
is the input view header even though the existing equal-width destination
storage still performs the copy.

The native data call appends `program, &functions, &copies` to the existing
`profiling::data` arguments and propagates its new Diagnostic Result with ?.
The final shared API and four frozen candidate hashes received a read-only
compatibility review from semantic_queries; it found no concrete contradiction
with its profiler candidate. No execution was performed for that review.

## Collection and reuse invariants

Only actual nonempty KIND_COPY intervals are recorded. Register/address setup
before `copy_bytes` is excluded; internal overlap tests and REP setup remain
inside its interval. Runtime/allocator region overrides prevent collection
before any role/path contract is constructed. Unknown typed attribution leaves
the existing KIND_COPY region unmapped instead of fabricating a row.

Body keeps the selected function index and receives the real emission-loop
instruction index. Rotation fusion advances that real index by seven; the
following copy never receives a compressed instruction count. Incoming
parameters use the all-ones instruction sentinel and original parameter index.
Constructor fields/array elements retain their original indices, including
scalar and zero-sized gaps. Elided/coalesced/scalar transfers produce no site.

Checkpoint and fragment metadata retain both relative endpoints. Append
preflights interval containment/order, KIND_COPY coverage, tags, origin/sentinel,
profile/region agreement and all relevant offset additions before mutating
bytes, labels or symbols. Cache preflight additionally checks the exact selected
function, instruction, subsite, payload type/tags and layout width.

The codec is LKJCODE3 and its namespace input is native-functions version 3.
Profiled fragments encode a count and 64-byte construction rows after kinds.
Ordinary fragments encode no copy-count field or rows. Old/malformed payloads
are refused and fall back to normal checked emission.

Ordinary emission retains empty Vec state and does not allocate site rows,
walk places for tags, construct a CopySite, serialize selected IR or add
application instructions. Fixed overhead remains: two usize Body coordinates,
empty Vec fields, checkpoint bookkeeping, a subsite argument and collection
branches. No zero-overhead or performance claim is made.

## Prepared tests and integration proposal

The existing `native::cache_contracts()` entry, reached from the semantic reuse
suite, now contains unexecuted cases for:

- two adjacent copy sites, cold/warm byte/kind/site parity at different offsets
  and with reused versus new literal labels;
- truncated/old/malformed tag and overflowing count decodes;
- empty/outside/overlapping intervals, zero width, sentinel-coordinate and
  reserved/place-flag failures before bytes/labels/symbols are changed;
- ordinary encoding with no site-count word, and runtime/allocator exclusion,
  including refusal to append a normal profiled fragment under a region override.

After the complete proposal is checked/applied and a worker is released, the
targeted acceptance sequence should be:

1. Build the integrated candidate and run the existing semantic reuse/cache
   contract entry. Add small selected-IR controls for wrong in-range owner/type,
   out-of-range instruction/subsite and width mismatch through valid_copies.
2. Compare ordinary emitted image bytes with the unchanged emitter on fixed
   source specimens. Run their original checked-IR interpreter oracles,
   including overlapping aggregate copies, ownership/drop behavior and traps.
3. Build a bounded profiled fixture containing incoming/return, whole-local and
   projected read/assign, Struct/Variant/Array with scalar/zero-size gaps, VecPush,
   VecPop, ArrayRepeat, BoxNew, Clone and StrAsBytes. Cover fixed copy widths
   1/2/4/8, 16/24/32, 33–128 and 129+, including owned/view values. Match each
   recorded type/tag/subsite to the exact companion, and check a copy following
   a recognized rotation sequence against the real post-inline instruction.
4. Exercise cold and warmed profiled fragments and compare metadata after
   relocation. Use the separate profiler/driver tests for digest binding,
   fallback selection, output alias/publication refusal, handler accounting,
   malformed tables and bounded continuations. Keep existing profile summary
   behavior and require one ordinary copy fixture to produce nonzero detail
   samples without any fixed-percentage assertion.

Those tests and all attribution measurements remain pending; these candidates
provide no new runtime observation, optimization result, backend floor or
whole-witness speed claim. The two preparatory gateway-only errors were an
extra nonexistent read path and a JavaScript parse error before candidate
mutation; neither invoked a compiler or changed tracked source.
