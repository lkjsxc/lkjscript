#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C
base=/home/coder/workspace/lkjscript-compiler-query-container-20261116/target/compiler-copy-sites-census-join-20261116
cd "$base"
expected=d3583950adc72bbc895254727ed752dd5454c81618b23326395207c693f1e3e1
printf '%s  %s\n' "$expected" join.pl | sha256sum -c -
test ! -e phase-1
test ! -L phase-1
mkdir -m 700 phase-1
cp join.pl phase-1/join.pl
printf '%s  %s\n' "$expected" phase-1/join.pl | sha256sum -c - > phase-1/script-pin.check
args=(perl "$base/phase-1/join.pl"
 --profile /home/coder/workspace/lkjscript/target/compiler-copy-sites-run.20261116-2/producer-profile64.samples.00000000000002892325
 --extraction /home/coder/workspace/lkjscript/target/compiler-copy-sites-census-output.20261116-1
 --acceptance /home/coder/workspace/lkjscript/bench/compiler-profile-copy-sites-cohort-2-acceptance/acceptance.json
 --layout /home/coder/workspace/lkjscript/src/native/layout.lkj
 --output "$base/phase-1/output")
printf '%s\0' "${args[@]}" > phase-1/argv.nul
printf '%q ' "${args[@]}" > phase-1/command.txt
printf '\n' >> phase-1/command.txt
printf '%s\n' "$PWD" > phase-1/cwd
printf '%s\n' 'address_space_kib=4194304' 'timeout_s=300' 'grace_s=10' > phase-1/limits.txt
cat /proc/loadavg > phase-1/load-before.txt
date -u +%Y-%m-%dT%H:%M:%SZ > phase-1/start.txt
set +e
/usr/bin/time -f 'elapsed_s=%e\nuser_s=%U\nsystem_s=%S\npeak_rss_kib=%M\nexit_status=%x' -o phase-1/time.txt \
 timeout --kill-after=10s 300s bash -c 'ulimit -v 4194304; exec "$@"' bounded-join "${args[@]}" \
 > phase-1/stdout 2> phase-1/stderr
status=$?
set -e
printf '%s\n' "$status" > phase-1/status
date -u +%Y-%m-%dT%H:%M:%SZ > phase-1/end.txt
cat /proc/loadavg > phase-1/load-after.txt
cat phase-1/status phase-1/time.txt phase-1/load-before.txt phase-1/load-after.txt
exit "$status"
