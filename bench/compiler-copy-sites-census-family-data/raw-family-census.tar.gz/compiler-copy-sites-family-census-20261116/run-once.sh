#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C
base=/home/coder/workspace/lkjscript-compiler-query-container-20261116/target/compiler-copy-sites-family-census-20261116
cd "$base"
expected=b4f3df6b6ffc443d7b3baf839b4e1dbdbb664a21f8ff366a437f05c5114113a6
printf '%s  %s\n' "$expected" families.pl | sha256sum -c -
test ! -e phase-1
test ! -L phase-1
mkdir -m 700 phase-1
cp families.pl phase-1/families.pl
printf '%s  %s\n' "$expected" phase-1/families.pl | sha256sum -c - > phase-1/script-pin.check
args=(perl "$base/phase-1/families.pl"
 --extraction /home/coder/workspace/lkjscript/target/compiler-copy-sites-census-output.20261116-1
 --join /home/coder/workspace/lkjscript-compiler-query-container-20261116/target/compiler-copy-sites-census-join-20261116/phase-1/output
 --output "$base/phase-1/output")
printf '%s\0' "${args[@]}" > phase-1/argv.nul
printf '%q ' "${args[@]}" > phase-1/command.txt
printf '\n' >> phase-1/command.txt
printf '%s\n' "$PWD" > phase-1/cwd
printf '%s\n' 'address_space_kib=4194304' 'timeout_s=300' 'grace_s=10' > phase-1/limits.txt
cat /proc/loadavg > phase-1/load-before.txt
date -u +%Y-%m-%dT%H:%M:%SZ > phase-1/start.txt
set +e
/usr/bin/time -f 'elapsed_s=%e\nuser_s=%U\nsystem_s=%S\npeak_rss_kib=%M\nexit_status=%x' -o phase-1/time.txt \
 timeout --kill-after=10s 300s bash -c 'ulimit -v 4194304; exec "$@"' bounded-family "${args[@]}" \
 > phase-1/stdout 2> phase-1/stderr
status=$?
set -e
printf '%s\n' "$status" > phase-1/status
date -u +%Y-%m-%dT%H:%M:%SZ > phase-1/end.txt
cat /proc/loadavg > phase-1/load-after.txt
cat phase-1/status phase-1/time.txt phase-1/load-before.txt phase-1/load-after.txt
exit "$status"
