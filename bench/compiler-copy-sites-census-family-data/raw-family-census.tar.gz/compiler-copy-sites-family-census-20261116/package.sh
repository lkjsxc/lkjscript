#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C
package=compiler-copy-sites-family-census-package-20261116
test ! -e "$package"
test ! -L "$package"
mkdir -m 700 "$package"
perl - "$package" <<'PERL'
use strict;use warnings;
use Cwd qw(abs_path);
use Digest::SHA;
use Fcntl qw(O_RDONLY O_NOFOLLOW :mode);
use File::Find;
use JSON::PP;
my $package=shift @ARGV;my $source='compiler-copy-sites-family-census-20261116';
my $root='/home/coder/workspace/lkjscript-compiler-query-container-20261116/target/'.$source;
die "unexpected owned source" unless abs_path($source) eq $root;
my(@files,@dirs);
find({no_chdir=>1,follow=>0,wanted=>sub{
 my $path=$File::Find::name;die "unexpected path" unless $path=~/\Acompiler-copy-sites-family-census-20261116(?:\/[A-Za-z0-9_.-]+)*\z/;
 my @before=lstat($path);die "missing entry" unless @before;
 if(S_ISDIR($before[2])){push @dirs,$path;return;}
 die "nonregular or linked file" unless S_ISREG($before[2])&&$before[3]==1;
 sysopen(my $f,$path,O_RDONLY|O_NOFOLLOW) or die "open $path";binmode $f;
 my @opened=stat($f);die "identity changed" unless $opened[0]==$before[0]&&$opened[1]==$before[1];
 my $sha=Digest::SHA->new(256);$sha->addfile($f);my @after=stat($f);
 for my $i(0,1,2,7,9,10){die "file changed while hashing" unless $before[$i]==$after[$i];}
 close $f or die "close";push @files,{path=>$path,bytes=>"$before[7]",sha256=>$sha->hexdigest};
}},$source);
@files=sort {$a->{path} cmp $b->{path}}@files;@dirs=sort @dirs;
my %by=map {$_->{path}=>$_} @files;
die "reader pin changed" unless $by{"$source/families.pl"}{sha256} eq 'b4f3df6b6ffc443d7b3baf839b4e1dbdbb664a21f8ff366a437f05c5114113a6';
die "output pin changed" unless $by{"$source/phase-1/output/manifest.sha256"}{sha256} eq '7c14fc93ff46c4ad19ba9d20625d9572e25a599e73066d0b826df0a925c74e9a';
my %extra_pins=(
 'run-once.sh'=>'51603557b926f48e1d60e7bc488df21b8731496f0bc75678252434c26699e8b4',
 'README.md'=>'5743d682fc070e659894c2095c6783342f5610fd7f52bdc8f90e45888be8c03b',
 'manual-review.json'=>'81acf9ca45d49c91eddc034cdbc5cd9f8cc1c5949122620bb80bacbc0ed530ef',
 'phase-1/families.pl'=>'b4f3df6b6ffc443d7b3baf839b4e1dbdbb664a21f8ff366a437f05c5114113a6',
 'phase-1/output/result.json'=>'1390bc573b5483ab08ae85c19383983132712b9e9bf57d3b9754cee4e023042e',
 'phase-1/stdout'=>'1390bc573b5483ab08ae85c19383983132712b9e9bf57d3b9754cee4e023042e',
 'phase-1/stderr'=>'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
);
for my $name(keys %extra_pins){die "proof pin $name" unless $by{"$source/$name"}{sha256} eq $extra_pins{$name};}
open(my $outm,'<',"$source/phase-1/output/manifest.sha256") or die "output manifest";
my $output_records=0;while(my $line=<$outm>){chomp $line;my($sha,$name)=$line=~/\A([0-9a-f]{64})  ([A-Za-z0-9_.\/-]+)\z/;
 die "output manifest record" unless defined($name)&&$name!~m{(?:\A|/)\.\.?(?:/|\z)};
 die "output record changed $name" unless $by{"$source/phase-1/output/$name"}{sha256} eq $sha;$output_records++;}
close $outm or die "output manifest close";
my $extraction='/home/coder/workspace/lkjscript/target/compiler-copy-sites-census-output.20261116-1';
my %copy_map=(
 'manual/fn2652-body.lkjir'=>'functions/13-function-2652/body.lkjir',
 'manual/fn2652-types.lkjir'=>'functions/13-function-2652/types.lkjir',
 'manual/fn2652-types.tsv'=>'functions/13-function-2652/types.tsv',
 'manual/fn2652-extraction.json'=>'functions/13-function-2652/extraction.json',
 'manual/fn2652-callee1295.lkjir'=>'functions/13-function-2652/signatures/function-1295.lkjir',
 'manual/shared-destructors.lkjir'=>'shared/destructors.lkjir',
 'manual/nonflat-copy-types.lkjir'=>'functions/17-function-690/types.lkjir',
 'manual/nonflat-copy-types.tsv'=>'functions/17-function-690/types.tsv'
);
my $copied=0;
for my $local(sort keys %copy_map){
 sysopen(my $f,"$extraction/$copy_map{$local}",O_RDONLY|O_NOFOLLOW)or die "copy input";
 my @a=stat($f);die "copy input not regular" unless S_ISREG($a[2]);
 binmode $f;my $s=Digest::SHA->new(256);$s->addfile($f);my @z=stat($f);close $f or die "copy input close";
 for my $i(0,1,2,7,9,10){die "copy input changed" unless $a[$i]==$z[$i];}
 die "copy correspondence $local" unless $s->hexdigest eq $by{"$source/$local"}{sha256};$copied++;
}
print "verified_output_records=$output_records\nverified_exact_context_copies=$copied\n";

my $bytes=0;$bytes+=$_->{bytes} for @files;
open(my $m,'>',"$package/inventory.sha256") or die "manifest";
print $m "$_->{sha256}  $_->{path}\n" for @files;close $m or die "manifest close";
open(my $j,'>',"$package/inventory.json") or die "JSON";
print $j JSON::PP->new->canonical->pretty->encode({source=>$root,regular_files=>"".scalar(@files),directories=>"".scalar(@dirs),logical_file_bytes=>"$bytes",files=>\@files,directory_paths=>\@dirs});
close $j or die "JSON close";
print "files=".scalar(@files)."\ndirectories=".scalar(@dirs)."\nlogical_bytes=$bytes\n";
PERL
tar --sort=name --format=gnu --mtime=@0 --owner=0 --group=0 --numeric-owner -cf - compiler-copy-sites-family-census-20261116 | gzip -n -9 > "$package/evidence.tar.gz"
gzip -t "$package/evidence.tar.gz"
sha256sum -c "$package/inventory.sha256" > "$package/after.check"
sha256sum "$package/evidence.tar.gz" "$package/inventory.sha256" "$package/inventory.json" > "$package/package.sha256"
stat --printf='archive_bytes=%s\n' "$package/evidence.tar.gz"
cat "$package/package.sha256"
