#!/usr/bin/env bash
# Root-authorized accounting-fixture validation, separate from prospective cohort.
set -euo pipefail
export LC_ALL=C
umask 077
cd /home/coder/workspace/lkjscript-compiler-query-container-20261116
base="$PWD/target/compiler-copy-sites-accounting-candidate"
run="$base/validation-1"
[[ ! -e $run && ! -L $run ]]
mkdir "$run"
mkdir "$run/inputs"
canonical=/home/coder/workspace/lkjscript/target/compiler-copy-sites-gate.ccpzZ9/canonical
original=/home/coder/workspace/lkjscript/target/compiler-copy-sites-integration-evidence
helper="$base/compiler-profile-copy-account.pl"
[[ $(sha256sum "$canonical" | cut -d ' ' -f 1) == 6cd52308aba91d6f84396e6f999ffba6d97eb7ccbacbb6bec654c31fee7bdacc ]]
[[ $(sha256sum "$helper" | cut -d ' ' -f 1) == 764923d22b26bbae6d266b3ccc353402b1417d8d878bc56e98975742c90b9213 ]]
sha256sum "$canonical" "$helper" "$original/roles.samples.00000000000002760523" "$original/roles.lkjir" > "$run/originals.before.sha256"
printf '%s\n' "$PWD" > "$run/cwd"
printf 'scope=retained58row_zero_fixture_and_synthetic_counter_validation\nnew_profile_execution=false\nfuture_measurement_input=false\nmemory_bytes=4294967296\ndeadline_seconds=60\ngrace_seconds=10\n' > "$run/scope"
completed=false
finish() {
    status=$?
    trap - EXIT HUP INT TERM
    printf 'status=%s\ncompleted=%s\n' "$status" "$completed" > "$run/outcome"
    exit "$status"
}
trap finish EXIT
trap 'exit 130' HUP INT TERM
capture() {
    local label=$1 expected=$2 needle=$3 status=0
    shift 3
    local dir="$run/$label"
    mkdir "$dir"
    printf '%s\n' "$PWD" > "$dir/cwd"
    perl -MJSON::PP -e 'print JSON::PP->new->canonical->encode(\@ARGV),"\n";' -- "$@" > "$dir/argv.json"
    date -u +%FT%TZ > "$dir/start.utc"
    date +%s%N > "$dir/start.ns"
    cut -d ' ' -f 1-3 /proc/loadavg > "$dir/load.before"
    /usr/bin/time -f '%e\t%U\t%S\t%M\t%x' -o "$dir/time" \
        /usr/bin/prlimit --as=4294967296 -- /usr/bin/timeout --kill-after=10s 60s \
        "$@" < /dev/null > "$dir/stdout" 2> "$dir/stderr" || status=$?
    printf '%s\n' "$status" > "$dir/status"
    date +%s%N > "$dir/end.ns"
    date -u +%FT%TZ > "$dir/end.utc"
    cut -d ' ' -f 1-3 /proc/loadavg > "$dir/load.after"
    printf '%s\t%s\t%s\t%s -> %s\n' "$label" "$status" "$(tail -n 1 "$dir/time")" \
        "$(cat "$dir/load.before")" "$(cat "$dir/load.after")"
    if [[ $expected == pass ]]; then
        [[ $status == 0 && ! -s $dir/stderr ]]
    else
        [[ $status == 255 && ! -s $dir/stdout ]]
        grep -qF "$needle" "$dir/stderr"
    fi
}
capture setup pass '' perl "$base/fixture-copies.pl" \
    "$original/roles.samples.00000000000002760523" "$original/roles.lkjir" "$run/inputs"
for fixture in roles synthetic-inflight; do
    capture "$fixture-summary" pass '' "$canonical" profile "$run/inputs/$fixture.lkjprof"
    capture "$fixture-detail" pass '' "$canonical" profile "$run/inputs/$fixture.lkjprof" \
        --copy-sites --profile-ir "$run/inputs/roles.lkjir" --limit 200 --bytes 1048576
    capture "$fixture-account" pass '' perl "$helper" --profile "$run/inputs/$fixture.lkjprof" \
        --companion "$run/inputs/roles.lkjir" --summary "$run/$fixture-summary/stdout" \
        --detail "$run/$fixture-detail/stdout" --output "$run/$fixture-derived"
done
# These are owned official-output copies with exactly one deliberately false value.
perl - "$run/roles-detail/stdout" "$run/inputs/bad-detail" <<'PERL'
use strict; use warnings; use Fcntl qw(O_WRONLY O_CREAT O_EXCL);
open my $f, '<:raw', $ARGV[0] or die $!; local $/; my $s=<$f>;
$s =~ s/ mapped=0 / mapped=1 / == 1 or die "detail fixture differs\n";
sysopen my $o, $ARGV[1], O_WRONLY|O_CREAT|O_EXCL,0600 or die $!; print {$o} $s or die $!; close $o or die $!;
PERL
perl - "$run/roles-summary/stdout" "$run/inputs/bad-summary" <<'PERL'
use strict; use warnings; use Fcntl qw(O_WRONLY O_CREAT O_EXCL);
open my $f, '<:raw', $ARGV[0] or die $!; local $/; my $s=<$f>;
$s =~ s/^kind 0\.0 0 inline copy$/kind 0.0 1 inline copy/m == 1 or die "summary fixture differs\n";
sysopen my $o, $ARGV[1], O_WRONLY|O_CREAT|O_EXCL,0600 or die $!; print {$o} $s or die $!; close $o or die $!;
PERL
for fixture in bad-reserved bad-counter-overflow bad-copy-offset; do
    case "$fixture" in
        bad-reserved) needle='E_COPY_ACCOUNT period or reserved header fields differ' ;;
        bad-counter-overflow) needle='E_COPY_ACCOUNT u64 counter overflow: completed kind total' ;;
        bad-copy-offset) needle='E_COPY_ACCOUNT copy section offset differs' ;;
    esac
    capture "$fixture-account" refuse "$needle" perl "$helper" \
        --profile "$run/inputs/$fixture.lkjprof" --companion "$run/inputs/roles.lkjir" \
        --summary "$run/roles-summary/stdout" --detail "$run/roles-detail/stdout" \
        --output "$run/$fixture-derived"
done
capture wrong-companion-account refuse 'E_COPY_ACCOUNT exact selected-IR companion digest differs' \
    perl "$helper" --profile "$run/inputs/roles.lkjprof" --companion "$run/inputs/wrong-companion.lkjir" \
    --summary "$run/roles-summary/stdout" --detail "$run/roles-detail/stdout" \
    --output "$run/wrong-companion-derived"
capture bad-detail-account refuse 'E_COPY_ACCOUNT official detail accounting differs at field 3' \
    perl "$helper" --profile "$run/inputs/roles.lkjprof" --companion "$run/inputs/roles.lkjir" \
    --summary "$run/roles-summary/stdout" --detail "$run/inputs/bad-detail" --output "$run/bad-detail-derived"
capture bad-summary-account refuse 'E_COPY_ACCOUNT official kind marginal differs' \
    perl "$helper" --profile "$run/inputs/roles.lkjprof" --companion "$run/inputs/roles.lkjir" \
    --summary "$run/inputs/bad-summary" --detail "$run/roles-detail/stdout" --output "$run/bad-summary-derived"
perl -MJSON::PP - "$run" <<'PERL'
use strict; use warnings;
my ($run)=@ARGV;
sub read_json { open my $f,'<:raw',$_[0] or die $!; local $/; return decode_json(<$f>); }
for my $fixture (qw(roles synthetic-inflight)) {
    my $a=read_json("$run/$fixture-derived/accounting.json");
    $a->{complete} && $a->{tables}{C} eq '58' or die "accounting status\n";
    my $c=$a->{counters};
    if ($fixture eq 'roles') {
        for my $key (qw(serial_S completed_T copy_kind_K mapped unmapped detail_D serial_minus_completed detail_minus_copy_in_flight)) {
            $c->{$key} eq '0' or die "zero fixture $key\n";
        }
    } else {
        my %wanted=(serial_S=>10,completed_T=>9,copy_kind_K=>5,mapped=>6,unmapped=>0,
            detail_D=>6,serial_minus_completed=>1,detail_minus_copy_in_flight=>1,
            function_self_total=>5,function_unattributed=>4);
        for my $key (keys %wanted) { $c->{$key} eq "$wanted{$key}" or die "synthetic $key\n"; }
    }
}
for my $fixture (qw(bad-reserved bad-counter-overflow bad-copy-offset wrong-companion bad-detail bad-summary)) {
    opendir my $d,"$run/$fixture-derived" or die $!;
    my @extra=grep {$_ ne '.' && $_ ne '..'} readdir $d;
    !@extra or die "refusal published derivation: $fixture\n";
}
print "ok retained zero profile, admitted synthetic in-flight state, and six precise refusals\n";
PERL
sha256sum -c "$run/originals.before.sha256" > "$run/originals.after.check"
completed=true
