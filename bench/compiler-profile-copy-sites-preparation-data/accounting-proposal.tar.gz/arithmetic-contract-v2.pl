#!/usr/bin/env perl
# Static arithmetic/encoding probes only; no profile, IR, compiler or filesystem input.
use strict;
use warnings FATAL => 'all';
use Config;
use JSON::PP;
use Math::BigInt;
$Config{ivsize} == 8 && $Config{uvsize} == 8 or die "64-bit Perl required\n";
sub dec { return join('', $_[0]); }
my $max = unpack('Q<', "\xff" x 8);
my $next = unpack('Q<', "\xfe" . ("\xff" x 7));
my $signed = unpack('Q<', ("\xff" x 7) . "\x7f");
dec($max) eq '18446744073709551615' or die "u64 maximum decoding lost precision\n";
dec($next) eq '18446744073709551614' or die "u64 neighboring value lost precision\n";
$max > $next && ($max <=> $next) == 1 && $max - $next == 1
    or die "u64 compare/subtract lost precision\n";
my $json = JSON::PP->new->canonical;
$json->encode({ maximum => dec($max), next => dec($next) })
    eq '{"maximum":"18446744073709551615","next":"18446744073709551614"}'
    or die "JSON observations are not exact strings\n";
my $sum = Math::BigInt->new(dec($next))->badd(1);
$sum->bstr eq dec($max) && $sum->copy->badd(1)->bcmp(dec($max)) == 1
    or die "checked aggregate boundary differs\n";
for my $value ('0', '1', '9', '18446744073709551615', '18446744073709551616') {
    my $aggregate = Math::BigInt->new($value);
    $json->encode({ aggregate => dec($aggregate->bstr) }) eq '{"aggregate":"' . $value . '"}'
        or die "BigInt result retained a numeric JSON flag\n";
}
my $capacity;
{ use integer; $capacity = ($signed - 160) / 72; }
dec($capacity) eq Math::BigInt->new(dec($signed))->bsub(160)->bdiv(72)->bstr
    or die "bounded extent division lost precision\n";
my $mask = unpack('Q<', pack('V2', 0x07ffffff, 0x00000007));
my $valid = unpack('Q<', pack('V2', 0x07020101, 0x00000007));
($valid & ~$mask) == 0 && ($max & ~$mask) != 0
    or die "tag mask lost high bits\n";
my @empty = (0..-1);
!@empty or die "empty table iteration differs\n";
print "ok exact u64 words/comparison, string JSON including BigInt results, BigInt overflow, signed bounded division, tag mask, empty range\n";
