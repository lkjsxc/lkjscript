#!/usr/bin/env perl
# Test-only owned copies; these counters are synthetic, never observations.
use strict;
use warnings;
use Digest::SHA qw(sha256_hex);
use Fcntl qw(O_WRONLY O_CREAT O_EXCL);
@ARGV == 3 or die "usage: MUTATE ROLE_PROFILE ROLE_IR DESTINATION\n";
my ($profile_path, $ir_path, $dest) = @ARGV;
sub raw { open my $f, '<:raw', $_[0] or die $!; local $/; return <$f>; }
sub save {
    my ($name, $bytes) = @_;
    sysopen(my $f, "$dest/$name", O_WRONLY | O_CREAT | O_EXCL, 0600) or die $!;
    binmode $f; print {$f} $bytes or die $!; close $f or die $!;
    print sha256_hex($bytes), "  $name\n";
}
my $profile = raw($profile_path);
my $ir = raw($ir_path);
sha256_hex($profile) eq '1f0912222954ccfc998e2ee27f8164c0e631381701b6ae1b04d1ae43907a27a1'
    && sha256_hex($ir) eq 'b323c6407a905ef3f7097406bd4659f728b9c252b27a70452789da7233b0154b'
    or die "fixture input pin differs\n";
sub word { return unpack('Q<', substr($_[0], $_[1], 8)); }
sub put { my ($ref,$at,$value)=@_; substr($$ref, $at, 8, pack('Q<', $value)); }
my $counter = word($profile, 48);
my $copy = word($profile, 112);
my $map = word($profile, 128);
word($profile, 24) == 0 && word($profile, 120) == 58 or die "fixture scope differs\n";
for my $kind (0..15) { word($profile, $counter + 8*$kind) == 0 or die "nonzero original counters\n"; }
for my $site (0..57) { word($profile, $copy + 72*$site + 16) == 0 or die "nonzero original site\n"; }
save('roles.lkjprof', $profile);
save('roles.lkjir', $ir);
my $state = $profile;
put(\$state, 24, 10);
put(\$state, $counter, 4);
put(\$state, $counter + 8, 5);
put(\$state, $copy + 16, 6);
my $function = word($profile, $copy + 24);
my $symbol = word($profile, $map + $function * 16 + 8);
$symbol < word($profile, 8) or die "fixture selected symbol differs\n";
my $row = 160 + $symbol * 64;
put(\$state, $row + 16, 5);
put(\$state, $row + 24, 5);
put(\$state, $row + 32, 9);
save('synthetic-inflight.lkjprof', $state);
my $reserved = $profile;
put(\$reserved, 72, 1);
save('bad-reserved.lkjprof', $reserved);
my $overflow = $profile;
put(\$overflow, 24, unpack('Q<', "\xff" x 8));
put(\$overflow, $counter, unpack('Q<', "\xff" x 8));
put(\$overflow, $counter + 8, 1);
save('bad-counter-overflow.lkjprof', $overflow);
my $offset = $profile;
put(\$offset, 112, unpack('Q<', "\xff" x 8));
save('bad-copy-offset.lkjprof', $offset);
save('wrong-companion.lkjir', $ir . "\n");
