# Prospective LKJPROF4 accounting helper

This untracked proposal implements the offline phase specified in
compiler-profile-copy-sites-measurement-plan.md, reviewed draft SHA-256
6bd73c58ce10a36cdc5fed7ba4fd5b1bf96f83e6550e7a572852b2884b955e37.
No measured profile, compiler, IR checker, profile decoder, or workload has run
under this proposal. The helper is not an admission checker or an execution
attestation.

## Exact interface

    perl HELPER --profile SAMPLE --companion I --summary SUMMARY --detail DETAIL --output DIR

Every option is required exactly once. DIR must be absent and is exclusively
created at entry; failure leaves that claim and any partial output visible.
The launcher invokes this helper once only after the successful official
default and bounded detail reports, with their capture-complete/exit records
kept separately. The copied helper digest belongs in the prelaunch release.
Use the same external 4 GiB address-space, 900 s deadline, 10 s grace envelope.

The current fixed protocol uses the first detail page only, no cursor, limit
200 and max reply bytes 1048576. This helper validates that exact policy.
It accepts all available first-page rows even when the byte bound stops
before row 200 and preserves its continuation. It does not fetch another page.

## Input and format boundary

The implementation was read from current main src/native/profiling.lkj,
SHA-256 59a6bdc97617130af9b7a0fbd3964952b31a48f2aa11dfac73416a0dad22fbe5,
with the finite tag matrix in src/x86.lkj. The later gated production/source
pins still have to be supplied and checked before measurement.

All inputs must open as regular files without following the final path
component. The profile is read into owned bytes; the companion is streamed
only for byte length and SHA-256. Neither matching metadata nor a digest
asserts filesystem freshness or kernel sealing.

The decoder validates:

- LKJPROF4, 160-byte header, exact 1 ms requested period, reserved zeros;
- all contiguous 64-byte symbol rows/names and code ranges, valid UTF-8,
  per-symbol count bounds and checked function-self sum;
- all ordered 16-byte kind intervals, 16 counters, canonical section offsets;
- every 72-byte site, address order/nonoverlap, whole function/kind containment,
  finite origin/role/flag matrix and synthetic-parameter sentinel;
- the full 16-byte selected-function map, unique emitted symbols, explicit
  all-ones unemitted sentinel, and exact EOF;
- exact selected-companion digest and full raw-profile digest;
- S-T in {0,1}, D-K in {0,1}, with D-K=1 only when S-T=1, and all u64 sum
  overflow refusals. No convenient row is decremented.

The native u64 words are exact only on the explicitly required 64-bit Perl.
All field offsets are bounded by signed file length before multiplication or
indexing. Counter aggregates use Math::BigInt, including an unbounded
overlapping inclusive sum. Output observations are decimal strings, not JSON
floating values. The separate arithmetic probe checks these host assumptions
without reading profile/IR bytes or invoking a compiler.

The helper cross-checks all ordinary report integer counts and the exact
top-function selection/order, while treating its displayed f64 percentages as
syntax/range-checked display values only. It cross-checks the detail header,
scope, accounting, every visible row's raw numeric/role fields and function
symbol name, then proves the page is the exact deterministic first prefix.
That proof scans C rows and does not materialize/sort C copies. The official
detail command alone independently parses/checks IR and validates all operand
roles, type identities, layout widths, selected names and function count. This
helper deliberately does not recreate or replace those semantic checks;
stdout's checked-ir label is not by itself proof that a command ran.

## Outputs

Successful completion produces exactly these eight files:

- accounting.json: input hashes/lengths, complete counters, section offsets/
  lengths, C/F, precise official-output correspondence, scope limitations;
- kinds.tsv: all 16 exact integer marginals, with interval counts;
- functions.tsv: every symbol including zeros, self/inclusive/last-seen serial,
  ranges/frame, selected slot or none, and JSON-escaped name;
- function-map.tsv: every selected slot and explicit unemitted sentinel;
- widths.tsv: exact observed widths, site/nonzero-site counts and sample sums;
- roles.tsv: origin/source/destination/place-flag buckets;
- width-roles.tsv: joint exact width plus those role fields;
- manifest.sha256: hashes of the other seven files.

Every bucket file ends with an explicit unmapped row. Its mapped-row sum equals
the complete raw mapped table; including unmapped sums to D, which may be K+1
for the one explicitly unlocated in-flight detail sample. No sample-by-width
product, byte traffic, removable time, SROA eligibility or causal effect is
computed. Zero-count sites remain in bucket site totals and in the retained
raw table. Inclusive function counts overlap and are not total CPU samples.

The 72*C + 16*F + 80-byte increment is a calculation against an otherwise equal
LKJPROF3 schema, with zero table alignment padding, not an observed old/new
producer delta. Both complete raw LKJPROF4 and selected IR remain separately
retained according to the launcher protocol.

## Validation state and proposed acceptance

Only syntax and arithmetic/encoding probes are authorized during preparation.
The revised helper passes perl -c without warnings. The separate bounded
arithmetic probe passes its exact-u64 decode/compare/subtract, string-JSON,
BigInt boundary, signed extent division, tag-mask and empty-range checks.
No LKJPROF4 or companion input has been passed to the helper.
The initial syntax check of draft6d8d619a succeeded but warned about a >32-bit
hex literal. The revised helper constructs that exact mask from two LE u32
words, removing the misleading portability warning under its explicit
64-bit-only contract; it also independently checks all bucket coverage sums.

No future measurement input may be used as a rehearsal. Before release, review
the decoder against the frozen production format and run ordinary bounded
offline fixture checks only if separately authorized: empty/zero-count profile;
a visible page shorter than C with ties/zero counts; maximum u64 accounting
and valid single interrupted states; malformed framing/UTF-8/map/tag/ranges;
companion/header mismatch; ordinary/detail output mismatch or wrong prefix;
and partial-output/refusal behavior. These do not authorize a compiler run,
new observer, race, kill campaign, or measured-workload retry.
