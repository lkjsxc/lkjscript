#!/usr/bin/env bash
# Root-authorized helper-only schema revalidation; no official decoder launch.
set -euo pipefail
export LC_ALL=C
umask 077
cd /home/coder/workspace/lkjscript-compiler-query-container-20261116
base="$PWD/target/compiler-copy-sites-accounting-candidate"
prior="$base/validation-1"
run="$base/validation-2"
[[ ! -e $run && ! -L $run ]]
mkdir "$run"
helper="$base/compiler-profile-copy-account.pl"
[[ $(sha256sum "$helper" | cut -d ' ' -f 1) == 0f938e92e961d94581f4424804f798c67cb168269af3de0734f4e7703d8fcb57 ]]
rg --files -0 "$prior" | sort -z | xargs -0 sha256sum > "$run/prior.before.sha256"
printf 'scope=helper_only_JSON_string_correction\nnew_official_decode=false\nnew_profile_execution=false\nfuture_measurement_input=false\nmemory_bytes=4294967296\ndeadline_seconds=60\ngrace_seconds=10\n' > "$run/scope"
completed=false
finish() {
    status=$?
    trap - EXIT HUP INT TERM
    printf 'status=%s\ncompleted=%s\n' "$status" "$completed" > "$run/outcome"
    exit "$status"
}
trap finish EXIT
trap 'exit 130' HUP INT TERM
capture() {
    local label=$1 expected=$2 needle=$3 status=0
    shift 3
    local dir="$run/$label"
    mkdir "$dir"
    printf '%s\n' "$PWD" > "$dir/cwd"
    perl -MJSON::PP -e 'print JSON::PP->new->canonical->encode(\@ARGV),"\n";' -- "$@" > "$dir/argv.json"
    date -u +%FT%TZ > "$dir/start.utc"
    date +%s%N > "$dir/start.ns"
    cut -d ' ' -f 1-3 /proc/loadavg > "$dir/load.before"
    /usr/bin/time -f '%e\t%U\t%S\t%M\t%x' -o "$dir/time" \
        /usr/bin/prlimit --as=4294967296 -- /usr/bin/timeout --kill-after=10s 60s \
        "$@" < /dev/null > "$dir/stdout" 2> "$dir/stderr" || status=$?
    printf '%s\n' "$status" > "$dir/status"
    date +%s%N > "$dir/end.ns"
    date -u +%FT%TZ > "$dir/end.utc"
    cut -d ' ' -f 1-3 /proc/loadavg > "$dir/load.after"
    printf '%s\t%s\t%s\t%s -> %s\n' "$label" "$status" "$(tail -n 1 "$dir/time")" \
        "$(cat "$dir/load.before")" "$(cat "$dir/load.after")"
    if [[ $expected == pass ]]; then
        [[ $status == 0 && ! -s $dir/stderr ]]
    else
        [[ $status == 255 && ! -s $dir/stdout ]]
        grep -qF "$needle" "$dir/stderr"
    fi
}
for fixture in roles synthetic-inflight; do
    capture "$fixture-account" pass '' perl "$helper" --profile "$prior/inputs/$fixture.lkjprof" \
        --companion "$prior/inputs/roles.lkjir" --summary "$prior/$fixture-summary/stdout" \
        --detail "$prior/$fixture-detail/stdout" --output "$run/$fixture-derived"
    for file in kinds.tsv functions.tsv function-map.tsv widths.tsv roles.tsv width-roles.tsv; do
        cmp "$prior/$fixture-derived/$file" "$run/$fixture-derived/$file"
    done
done
for fixture in bad-reserved bad-counter-overflow bad-copy-offset; do
    case "$fixture" in
        bad-reserved) needle='E_COPY_ACCOUNT period or reserved header fields differ' ;;
        bad-counter-overflow) needle='E_COPY_ACCOUNT u64 counter overflow: completed kind total' ;;
        bad-copy-offset) needle='E_COPY_ACCOUNT copy section offset differs' ;;
    esac
    capture "$fixture-account" refuse "$needle" perl "$helper" \
        --profile "$prior/inputs/$fixture.lkjprof" --companion "$prior/inputs/roles.lkjir" \
        --summary "$prior/roles-summary/stdout" --detail "$prior/roles-detail/stdout" \
        --output "$run/$fixture-derived"
done
capture wrong-companion-account refuse 'E_COPY_ACCOUNT exact selected-IR companion digest differs' \
    perl "$helper" --profile "$prior/inputs/roles.lkjprof" --companion "$prior/inputs/wrong-companion.lkjir" \
    --summary "$prior/roles-summary/stdout" --detail "$prior/roles-detail/stdout" \
    --output "$run/wrong-companion-derived"
capture bad-detail-account refuse 'E_COPY_ACCOUNT official detail accounting differs at field 3' \
    perl "$helper" --profile "$prior/inputs/roles.lkjprof" --companion "$prior/inputs/roles.lkjir" \
    --summary "$prior/roles-summary/stdout" --detail "$prior/inputs/bad-detail" --output "$run/bad-detail-derived"
capture bad-summary-account refuse 'E_COPY_ACCOUNT official kind marginal differs' \
    perl "$helper" --profile "$prior/inputs/roles.lkjprof" --companion "$prior/inputs/roles.lkjir" \
    --summary "$prior/inputs/bad-summary" --detail "$prior/roles-detail/stdout" --output "$run/bad-summary-derived"
perl -MJSON::PP -MB - "$run" <<'PERL' > "$run/schema-check.stdout" 2> "$run/schema-check.stderr"
use strict; use warnings;
my ($run)=@ARGV;
sub read_json { open my $f,'<:raw',$_[0] or die $!; local $/; return decode_json(<$f>); }
sub strings_only {
    my ($value)=@_;
    if (ref($value) eq 'HASH') { strings_only($_) for values %$value; }
    elsif (ref($value) eq 'ARRAY') { strings_only($_) for @$value; }
    elsif (ref($value) eq 'JSON::PP::Boolean') {}
    elsif (ref($value)) { die "unexpected reference type\n"; }
    else {
        defined($value) or die "unexpected null\n";
        my $flags=B::svref_2object(\$value)->FLAGS;
        ($flags & (B::SVp_IOK()|B::SVp_NOK())) == 0
            or die "unquoted numeric JSON observation\n";
    }
}
for my $fixture (qw(roles synthetic-inflight)) {
    my $a=read_json("$run/$fixture-derived/accounting.json");
    strings_only($a);
    strings_only(read_json("$run/$fixture-account/stdout"));
    $a->{complete} && $a->{tables}{C} eq '58' or die "accounting status\n";
    my $c=$a->{counters};
    my %wanted=$fixture eq 'roles'
        ? (serial_S=>0,completed_T=>0,copy_kind_K=>0,mapped=>0,unmapped=>0,
           detail_D=>0,serial_minus_completed=>0,detail_minus_copy_in_flight=>0)
        : (serial_S=>10,completed_T=>9,copy_kind_K=>5,mapped=>6,unmapped=>0,
           detail_D=>6,serial_minus_completed=>1,detail_minus_copy_in_flight=>1,
           function_self_total=>5,function_unattributed=>4);
    for my $key (keys %wanted) { $c->{$key} eq "$wanted{$key}" or die "counter $fixture $key\n"; }
}
for my $fixture (qw(bad-reserved bad-counter-overflow bad-copy-offset wrong-companion bad-detail bad-summary)) {
    opendir my $d,"$run/$fixture-derived" or die $!;
    my @extra=grep {$_ ne '.' && $_ ne '..'} readdir $d;
    !@extra or die "refusal published derivation: $fixture\n";
}
print "ok all JSON observations are strings; both counter states and six precise refusals retained\n";
PERL
sha256sum -c "$run/prior.before.sha256" > "$run/prior.after.check"
completed=true
