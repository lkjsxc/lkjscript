# Offline copy-site body extractor proposal

This untracked proposal implements extraction only for the prospective review
frozen in root's compiler-copy-sites-census-plan.md, SHA-256
8a1f3e3d5354b3eca7fd9adb68bfee892f94360130a19b265f3f9ffb73c4dc15.
It has not opened any future measurement profile, companion, or detail page.
No compiler, profiler, accounting helper, optimizer, or source program is run by
this extractor. No eligibility, gain, traffic, or removable-time result follows
from a successful extraction.

## Interface and authority boundary

    perl compiler-copy-sites-extract.pl \
      --companion EXACT_SELECTED_IR \
      --detail SOLE_CAPTURED_FIRST_DETAIL_PAGE \
      --output ABSENT_OUTPUT_DIRECTORY

The output parent must exist. The basename is restricted, the output directory
is claimed exclusively, and every output file is created exclusively. Both
inputs are opened as regular files without following a final symlink, copied
byte-for-byte into inputs/, and hashed. Subsequent byte-range extraction reads
the owned companion copy. Input metadata and length are checked across copying;
this is an observation of the captured bytes, not a filesystem sealing claim.

The detail companion digest must equal the exact owned IR bytes. Header, scope,
row framing and first-page continuation are checked. The row names and displayed
function/type/instruction coordinates are checked against the parsed companion.
The declared profile digest is retained. This tool does not open the profile,
prove the sample counters, authenticate the detail producer, or independently
admit IR. The separately retained official detail command, its successful status,
and accepted profile/companion pins remain prerequisites. A forged report header
cannot itself grant checker authority.

Only the first 20 distinct function indices in the supplied page are selected,
in first-appearance order. A parameter row selects its function. There is no
replacement, second-page fetch, population override, unseen-site join or
whole-program eligibility conclusion. Fewer distinct functions selects fewer.

## Fixed limits and failure behavior

Per selected function:

| Material | Limit |
| --- | ---: |
| Body instructions | 65,536 |
| Exact fn/endfn block | 16 MiB |
| Distinct referenced type closure | 16,384 |
| Unique direct-call/relevant-destructor signatures | 2,048 |
| Body plus complete required raw context | 32 MiB |

The complete shared source/destructor records count toward each function's
logical context even though they are stored once. Context size also includes
the complete exact body, each referenced type block, and every retained signature
record. Derived JSON/TSV indexes and the separately retained full input copy are
not represented as additional IR context bytes.

The first page is capped at 200 rows and 1 MiB. There is an additional explicit
32 MiB maximum single IR line while scanning, before Unicode tokenization. A line
beyond that guard produces an unassessed extraction; it is never truncated.
This may conservatively stop indexing because of an unrelated oversized record.

A free-space observation requires 3 GiB before claiming the output. Future
released use must retain the external 4 GiB address-space limit, 300 s watchdog
and 10 s grace specified by the census plan. These are offline extraction
bounds, not language limits or authenticated query latency promises. Resource
termination or a partial output directory is not successful extraction.

A per-function missing dependency, unsupported operation or exceeded bound is
recorded as unassessed, with no partial body/context export. The exact full input
copy remains available. Such a run exits 2. A global framing/format/input failure
records unassessed-extraction and exits 1. Exit 0 means extraction completeness
for this bounded population only. Both exit-zero and nonzero outputs say
eligibility=not-assessed.

## Grammar and context

The quoted-word lexer follows current ir_text::words: UTF-8; Unicode White_Space;
comments beginning at # outside quotes; quoted separators; JSON-style escapes;
paired UTF-16 surrogates; and rejection of raw Cc characters, lone surrogates and
quotes within unquoted words. Source grammar SHA-256 is
af4c78b51063bce8a24e2a35bd364a48cbb3a888d01c1fd6219faa3d5983d4f8.
Detail display names use the official report's JSON quoting, whose control-
character spelling differs from IR text. The extractor is a structural indexer,
not a replacement for ir_text::read plus the independent checker: intrinsic/
unary/binary semantic inventories and full value/loan validity stay with that
official admission.

Type and function identities remain declaration-order indices. Enum blocks
include every variant and endtype. Every selected body includes its fn header,
all return-leaf records, all locals, instructions, comments within the span, and
endfn. Body instruction coordinates exclude locals, return contracts and framing.
Instruction source coordinates are retained; default source-file selection is
labelled default rather than invented.

A visited-set closure starts at the selected function's result and every local
type. It follows fields, variants, arrays, vectors, boxes, references and slices.
Every direct Op::Call contributes its exact callee signature; relevant destructor
declarations contribute destructor signatures. Those signature parameter/result
types extend the type closure to a fixed point. Cycles do not truncate it.

A signature is the exact original fn record, all returned-view contract records,
the first parameter-count local records, and endfn, in their original record
order. Its components have independent original byte offsets and hashes.
It is a signature excerpt, not an admitted standalone IR program. Callee and
destructor bodies are not silently included. A later decision depending on a
destructor's behavior still needs its whole body under a separate reviewed step.

All source records and the entire destructor declaration table are shared exact
bytes, with original record indices/ranges/hashes. The tool never reads the
filesystem paths named by source records. It does not manufacture native field
offsets, layout facts, drop behavior, or serialized loan states. The complete
companion is retained for later separately authorized context work.

## Output

- inputs/companion.lkjir and inputs/detail.txt: exact original bytes.
- shared/sources.lkjir, shared/destructors.lkjir and shared/index.tsv:
  complete shared record sets and their original byte ranges.
- selection.tsv: selection order, original function index, first page row,
  counts, completeness status and reasons.
- functions/ORDINAL-function-ID/body.lkjir: complete exact body for a complete
  extraction, with its digest in extraction.json.
- types.lkjir/types.tsv: complete type-closure blocks and original identities.
- signatures/: per-callee exact signature excerpts; signatures.tsv and
  signature-parts.tsv retain their identity/reason and each original component.
- instructions.tsv: original body instruction index, exact text range/digest,
  operation and explicit source coordinates.
- per-function and top-level extraction.json: extraction results and limitations.
- manifest.sha256: every published artifact except the manifest itself.

Fragments retain original IDs; concatenating a subset does not renumber it.
They are not newly admitted standalone programs.

## Validation retained so far

Only the already retained role fixture was used:

- roles.lkjir: 59,965 B, SHA-256
  b323c6407a905ef3f7097406bd4659f728b9c252b27a70452789da7233b0154b.
- Existing roles-profile-detail-1/stdout: 13,319 B, SHA-256
  7fc74a8882e9ddbf42c582a5e00ff89c668901a77153e0eea053ffa708ac219b.
- That page describes 58 copy rows with zero samples. It is not a new profile.

All versions and outcomes remain:

1. review-v1.pl (9125d456…) was a static draft. A two-file write request exceeded
   the gateway's 64 KiB argument limit and changed nothing; it was split.
2. review-v2.pl (8916d8fd…) failed perl -c because helper name s conflicted with
   Perl substitution syntax. static-1 records exit 2, 0.01 s, 10,140 KiB,
   load 5.64/3.93/2.81 unchanged.
3. review-v3.pl (2d7aef2b…) renamed that helper to dec. static-2 passed in 0.02 s,
   10,216 KiB, load 5.06/3.91/2.84 unchanged. validation-1 then refused with
   short snapshot range because buffered read was mixed with sysseek.
   Exit 1, 0.05 s, 11,732 KiB, load 4.13/3.78/2.82 unchanged; raw output and
   partial extraction manifest remain.
4. Current compiler-copy-sites-extract.pl (9ca679c6…) uses sysread consistently
   for the seeked IR handle. validation-2 completed extraction for the six
   distinct displayed functions: exit 0, 0.06 s, 12,016 KiB,
   load 2.33/3.36/2.72 unchanged. Both original input hashes remained unchanged.
   Its output manifest is
   34f40735cfde5385402b1454165b860f68d88ae7facaa3cc33f4c93a8df36be8.

Each timed validation was under 4 GiB / 60 s / 10 s, with argv, cwd, status,
stdout, stderr, GNU time and before/after load retained. It ran only this offline
extractor; no official decoder was rerun. The measurement hold arrived after
validation-2 finished. No further validation or substantial scan has run during
the cohort.

The permitted fixture is small, has only six selected functions, no continuation,
and does not exercise the 20-function cutoff, large-body/type/signature/context
boundaries or every quoted escape. Those remain explicit validation limitations.
The separate range/manifest audit proposal has not yet run. No future cohort
input has been opened, and later use requires root's exact-pin release.
